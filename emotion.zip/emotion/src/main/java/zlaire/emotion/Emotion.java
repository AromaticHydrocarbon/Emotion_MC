package zlaire.emotion;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.logging.LogUtils;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

import net.minecraft.commands.CommandFunction;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.commands.TitleCommand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.InterModComms;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.InterModEnqueueEvent;
import net.minecraftforge.fml.event.lifecycle.InterModProcessEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

import zlaire.emotion.world.structure.ModStructures;

import java.util.Objects;
import java.util.stream.Collectors;

import static java.lang.System.in;

// The value here should match an entry in the META-INF/mods.toml file
@Mod("emotion")
public class Emotion {

    // Directly reference a slf4j logger
    public static final Logger LOGGER = LogUtils.getLogger();

    public Emotion() {
        // Register the setup method for modloading
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        // Register the enqueueIMC method for modloading
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::enqueueIMC);
        // Register the processIMC method for modloading
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::processIMC);

        // 通常在模组主类的构造方法注册事件监听器
        MinecraftForge.EVENT_BUS.addListener(EventHandler::onLoggedIn);
        MinecraftForge.EVENT_BUS.addListener(EventHandler::pickUpItem);
        MinecraftForge.EVENT_BUS.addListener(EventHandler::tossItem);
        //MinecraftForge.EVENT_BUS.addListener(EventHandler::livingAttack);
        MinecraftForge.EVENT_BUS.addListener(EventHandler::entityPlace);
        MinecraftForge.EVENT_BUS.addListener(EventHandler::livingDeath);
        MinecraftForge.EVENT_BUS.addListener(EventHandler::breakBlock);

        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();


        //添加这个
        ModStructures.register(bus);


        // 实例注册到Forge总线中
        //MinecraftForge.EVENT_BUS.register(new MyForgeEventHandler());
        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);
    }

    public static class EventHandler {
        static Minecraft minecraft = Minecraft.getInstance();
        public static void onLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
            var player = event.getPlayer();
            player.sendMessage(new TextComponent("Player logged in"), Util.NIL_UUID);
        }

        public static void pickUpItem(EntityItemPickupEvent event) {
            Player player = event.getPlayer();
            var item= event.getItem();
            String command="title @a title {\"text\":\"Are you joyful\"}";
            String command1="title @a subtitle {\"text\":\"for having foods in your bag?\"}";
            if(item.getItem().isEdible()){
                Objects.requireNonNull(player.getServer()).getCommands().performCommand(player.getServer().createCommandSourceStack(),command);
                Objects.requireNonNull(player.getServer()).getCommands().performCommand(player.getServer().createCommandSourceStack(),command1);
            }
            String item_name = item.getName().getString();
            player.sendMessage(new TextComponent("Item "+item_name+" pick up"), Util.NIL_UUID);
        }

        public static void tossItem(ItemTossEvent event) {
            Player player = event.getPlayer();
            var item= event.getEntityItem();
            String item_name = item.getName().getString();
            player.sendMessage(new TextComponent("Item "+item_name+" toss"), Util.NIL_UUID);
        }

        public static void livingAttack(LivingAttackEvent event) {
            DamageSource source = event.getSource();
            var living= event.getEntityLiving();
            String living_name = living.getName().getString();
            String source_name=source.toString();
            minecraft.player.sendMessage(new TextComponent(living_name+" is attacked by "+source_name), Util.NIL_UUID);
        }
        public static void entityPlace(BlockEvent.EntityPlaceEvent event) {
            var block= event.getPlacedBlock().getBlock();
            String block_name = block.getDescriptionId();
            minecraft.player.sendMessage(new TextComponent(block_name+" is placed"), Util.NIL_UUID);

        }

        public static void breakBlock(BlockEvent.BreakEvent event){
            Player player = event.getPlayer();
            String command="title @a title {\"text\":\"Are you joyful\"}";
            String command1="title @a subtitle {\"text\":\"for being able to make new wooden tools\"}";

            var block= event.getState().getBlock();
            String block_name = block.getDescriptionId();
            if(block_name.contains("log")||block_name.contains("wood"))
            {
                Objects.requireNonNull(player.getServer()).getCommands().performCommand(player.getServer().createCommandSourceStack(),command);
                Objects.requireNonNull(player.getServer()).getCommands().performCommand(player.getServer().createCommandSourceStack(),command1);
            }
            minecraft.player.sendMessage(new TextComponent(block_name+" is break"), Util.NIL_UUID);
        }

        public static void livingDeath(LivingDeathEvent event) {
            DamageSource source = event.getSource();
            var living= event.getEntityLiving();
            String living_name = living.getName().getString();
            String source_name=source.toString();
            minecraft.player.sendMessage(new TextComponent(living_name+" die from "+source_name), Util.NIL_UUID);
        }
    }

    private void setup(final FMLCommonSetupEvent event) {
        // Some preinit code
        LOGGER.info("HELLO FROM PREINIT");
        LOGGER.info("DIRT BLOCK >> {}", Blocks.DIRT.getRegistryName());
    }

    private void enqueueIMC(final InterModEnqueueEvent event) {
        // Some example code to dispatch IMC to another mod
        InterModComms.sendTo("emotion", "helloworld", () -> {
            LOGGER.info("Hello world from the MDK");
            return "Hello world";
        });
    }

    private void processIMC(final InterModProcessEvent event) {
        // Some example code to receive and process InterModComms from other mods
        LOGGER.info("Got IMC {}", event.getIMCStream().
                map(m -> m.messageSupplier().get()).
                collect(Collectors.toList()));
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        // Do something when the server starts
        LOGGER.info("HELLO from server starting");
    }

    // You can use EventBusSubscriber to automatically subscribe events on the contained class (this is subscribing to the MOD
    // Event bus for receiving Registry Events)
    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class RegistryEvents {
        @SubscribeEvent
        public static void onBlocksRegistry(final RegistryEvent.Register<Block> blockRegistryEvent) {
            // Register a new block here
            LOGGER.info("HELLO from Register Block");
        }
    }
}
